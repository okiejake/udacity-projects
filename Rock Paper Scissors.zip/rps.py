#!/usr/bin/env python3

import random

"""This program plays a game of Rock, Paper, Scissors between two Players,
and reports both Player's scores each round."""

"""The Player class is the parent class for all of the Players
in this game"""


class Player:
    moves = ['rock', 'paper', 'scissors']

    def __init__(self):

        self.my_move = self.moves
        self.their_move = random.choice(self.moves)


class RandomPlayer(Player):
    def move(self):
        return random.choice(self.moves)


class ReflectPlayer(Player):

    def learn(self, my_move, their_move):
        self.my_move = my_move
        self.their_move = their_move

    def move(self):
        return self.their_move


class CyclePlayer(Player):

    def learn(self, my_move, their_move):
        self.my_move = my_move
        self.their_move = their_move

    def move(self):
        if self.my_move == self.moves[0]:
            return self.moves[1]
        elif self.my_move == self.moves[1]:
            return self.moves[2]
        else:
            return self.moves[0]


class HumanPlayer(Player):

    def learn(self, my_move, their_move):
        self.my_move = my_move
        self.their_move = their_move

    def move(self):
        while True:

            self.human_move = (input("Your turn! Rock, paper, or scissors?: "))

            if self.human_move.lower() in self.moves:
                return self.human_move.lower()
            elif self.human_move.isdigit():
                print(
                    "Ok smartbutt we're done with numbers. "
                    "Rock, paper, or scissors?")
            else:
                print("Hmm.. I didn't quite recognize that one. Try again.")


class Game:
    def __init__(self, p1, p2):
        self.p1 = p1
        self.p2 = p2
        # init scores
        self.score_p1 = 0
        self.score_p2 = 0

    def beats(self, one, two):
        return ((one == 'rock' and two == 'scissors') or
                (one == 'scissors' and two == 'paper') or
                (one == 'paper' and two == 'rock'))

    def rounds(self):
        while True:
            try:
                self.number_rounds = int(input("How many rounds would you "
                                               "like to play?: "))

            except ValueError:
                print("Oops, numbers only silly.")
                continue

            if self.number_rounds <= 10:
                return self.number_rounds
            elif self.number_rounds > 10:
                print(
                    "Wow... That's a lot of rounds. "
                    "Let's do 10 or less, please.")

    def play_round(self):
        move1 = self.p1.move()
        move2 = self.p2.move()
        if self.beats(move1, move2):
            self.score_p1 += 1
            winner = "Player one wins!"
        elif move1 == move2:
            self.score_p1 = self.score_p1
            self.score_p2 = self.score_p2
            winner = "It's a tie!"
        else:
            self.score_p2 += 1
            winner = "Player two wins!"
        print(
            f"Player one played : {move1}"
            f"\nPlayer two played : {move2}"
            f"\n{winner}"
            f"\nScore: Player one: {self.score_p1},"
            f" Player two {self.score_p2}"
        )
        self.p1.learn(move1, move2)
        self.p2.learn(move2, move1)

    def play_game(self):
        print("Game start!")

        self.rounds()
        for round in range(int(self.number_rounds)):
            print(f"Round {round + 1}:")
            self.play_round()
        if self.score_p1 == self.score_p2:
            print(
                f"Tie round!"
            )
        elif self.score_p1 > self.score_p2:
            print(
                f"Player one wins this round!"
            )

        else:
            print(
                f"Player two wins this round!"
            )

        print(
            "Game over! "
            "\nFinal score: Player one: " + str(self.score_p1) +
            " Player two: " + str(self.score_p2)
        )
        if self.score_p1 > self.score_p2:
            print("Player one wins!")
        elif self.score_p1 < self.score_p2:
            print("Player two wins!")
        else:
            print("It's a tie!")


if __name__ == '__main__':
    # game = Game(HumanPlayer(), random.choice(
    #    [RandomPlayer(), ReflectPlayer(), CyclePlayer()]))
    game = Game(HumanPlayer(), ReflectPlayer())

    game.play_game()
