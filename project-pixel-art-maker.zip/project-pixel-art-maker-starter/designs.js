var colorPicker = document.getElementById('colorPicker');
const canvas = document.getElementById('pixelCanvas');
var size = document.getElementById('sizePicker')

let numR = document.getElementById('inputHeight');
let numC = document.getElementById('inputWidth');

// trigger makeGrid function when clicking submit button
size.addEventListener('submit', function(e){
  e.preventDefault();

    makeGrid(numR.value, numC.value);
//  console.log(e + 'test');
//  console.log(numR.value, numC.value);
});

function makeGrid(h, w) {

// clear table before making a new one
canvas.innerHTML = "";

// create grid
  for (let i = 0; i < h; i ++){
    let row = canvas.insertRow(i);
    for (let j = 0; j < w; j++){
      let cell = row.insertCell(j);
      // look for click on each cell and change backgroundColor
      cell.addEventListener('click', function(e){
  //      console.log(e);
        cell.style.backgroundColor = colorPicker.value;
      });
    }
  }
}
